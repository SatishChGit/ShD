package com.teradata.systemhealth.dao;

import java.sql.Timestamp;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.teradata.systemhealth.model.SystemHealth;
import com.teradata.systemhealth.util.Constants;

@Mapper
public interface SystemHealthRepository {

	@Select(Constants.GET_SYSTEM_BY_ID)
	SystemHealth findBySystemId(@Param("systemId") Integer systemId, @Param("time") Timestamp time);
}
