package com.teradata.systemhealth.controller;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.teradata.systemhealth.model.Health;
import com.teradata.systemhealth.model.SystemHealth;
import com.teradata.systemhealth.service.SystemHealthService;
import com.teradata.systemhealth.util.SystemHealthUtil;

@RestController
@RequestMapping(path = "/systemhealth")
public class SystemHealthController {

	@Autowired
	private SystemHealthService service;

	@RequestMapping(value = "/systems/{systemId}", method = RequestMethod.GET)
	@ResponseBody
	public SystemHealth getSystemHealth(@PathVariable Integer systemId,
			@RequestParam(value = "time", required = false) String time) {
		SystemHealth health = new SystemHealth();
		health.setHealth(Health.CRITICAL);
		health.setSystemId(5);
		Timestamp timeStamp = SystemHealthUtil.getTimestamp(time);
		health = service.getSystemHealth(systemId, timeStamp);
		if (health == null) {
			health = new SystemHealth();
			health.setSystemId(systemId);
			health.setHealth(Health.UNKNOWN);
		}
		System.out.println("after response " + health);
		return health;
	}



}
