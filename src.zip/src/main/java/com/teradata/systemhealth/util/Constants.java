package com.teradata.systemhealth.util;

public interface Constants {
	
 String GET_SYSTEM_BY_ID =	" SELECT * FROM system_health WHERE systemId = ${systemId} AND logTime = (SELECT MAX(logTime) "
			+ " FROM system_health WHERE systemId = ${systemId} AND logTime < TIMESTAMP WITH TIME ZONE '${time}' AND logTime > TIMESTAMP WITH TIME ZONE "
			+ " '${time}') LIMIT 1";

}
