package com.teradata.systemhealth.util;

import java.sql.Timestamp;

public class SystemHealthUtil {
	
	/**
	 * Get Timestamp when time is provided or get the current timestamp
	 * 
	 * @return timestamp
	 * 
	 */
	public static Timestamp getTimestamp(String time) {
		Timestamp timeStamp;
		if (time != null && time.length() > 0) {
			timeStamp = new Timestamp(new Long(time));
		} else {
			timeStamp = new Timestamp(java.lang.System.currentTimeMillis());
		}
		return timeStamp;
	}

}
