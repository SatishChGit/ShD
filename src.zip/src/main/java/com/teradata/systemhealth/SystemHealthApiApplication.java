package com.teradata.systemhealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemHealthApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemHealthApiApplication.class, args);
	}
}
