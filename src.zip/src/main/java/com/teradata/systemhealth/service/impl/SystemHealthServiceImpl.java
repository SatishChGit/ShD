package com.teradata.systemhealth.service.impl;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.teradata.systemhealth.dao.SystemHealthRepository;
import com.teradata.systemhealth.model.SystemHealth;
import com.teradata.systemhealth.service.SystemHealthService;

@Service
public class SystemHealthServiceImpl implements SystemHealthService {
	
    @Autowired
    private SystemHealthRepository repo;
    
    public SystemHealth getSystemHealth(Integer systemId, Timestamp time) {
    	System.out.println("servce systemId : " + systemId);
    	System.out.println("servce time : " + time);
    	return repo.findBySystemId(systemId, time);
    }

}
