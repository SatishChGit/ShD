package com.teradata.systemhealth.service;

import java.sql.Timestamp;

import com.teradata.systemhealth.model.SystemHealth;


public interface SystemHealthService {
	public SystemHealth getSystemHealth(Integer systemId, Timestamp time);
}
