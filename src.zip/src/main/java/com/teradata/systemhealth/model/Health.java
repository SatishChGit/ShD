/*
 * Copyright (C) 2008 by Teradata Corporation. All Rights Reserved. TERADATA CORPORATION
 * CONFIDENTIAL AND TRADE SECRET
 */

package com.teradata.systemhealth.model;

public enum Health
{
    /**
     * Represents an unknown system health.
     */
    UNKNOWN,

    /**
     * Represents a health system health.
     */
    HEALTHY,

    /**
     * Represents a degraded system health.
     */
    DEGRADED,

    /**
     * Represents a critical system health.
     */
    CRITICAL,

    /**
     * Represents a down system health.
     */
    DOWN;

}
