/*
 * Copyright (C) 2015 by Teradata Corporation. All Rights Reserved. TERADATA CORPORATION
 * CONFIDENTIAL AND TRADE SECRET
 */
package com.teradata.systemhealth.model;

import java.sql.Timestamp;

/**
 * The information for a Overview of System Health.
 * 
 * @author sd186003
 * @version $Id: $
 */
public class SystemHealth
{

    // Internal ID of the monitored system
    private Integer systemId;

    // Name of the monitored system
    private String systemName;

    // Type of the monitored system (TERADATA, ASTER, HADOOP)
    private String systemType;

    // Timestamp when the system health was calculated
    private Timestamp timestamp;

    // The health of the system.
    private Health health;

    /**
     * Default empty constructor
     */
    public SystemHealth()
    {
    }


    public SystemHealth(Integer systemId, String systemName, String systemType,
            Timestamp timestamp, Health health)
    {
        this.systemId = systemId;
        this.systemName = systemName;
        this.timestamp = timestamp;
        this.systemType = systemType;
        this.health = health;
    }

    /**
     * @return the systemId
     */
    public Integer getSystemId()
    {
        return systemId;
    }

    /**
     * @param systemId
     *            the systemId to set
     */
    public void setSystemId(Integer systemId)
    {
        this.systemId = systemId;
    }

    /**
     * @return the systemName
     */
    public String getSystemName()
    {
        return systemName;
    }

    /**
     * @param systemName
     *            the systemName to set
     */
    public void setSystemName(String systemName)
    {
        this.systemName = systemName;
    }

    /**
     * @return the systemType
     */
    public String getSystemType()
    {
        return systemType;
    }

    /**
     * @param systemType
     *            the systemType to set
     */
    public void setSystemType(String systemType)
    {
        this.systemType = systemType;
    }

    /**
     * @return the timestamp
     */
    public Timestamp getTimestamp()
    {
        return timestamp;
    }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    public void setTimestamp(Timestamp timestamp)
    {
        this.timestamp = timestamp;
    }

    /**
     * @return the systemHealth
     */
    public Health getHealth()
    {
        return health;
    }

    /**
     * @param systemHealth
     *            the systemHealth to set
     */
    public void setHealth(Health health)
    {
        this.health = health;
    }

}
