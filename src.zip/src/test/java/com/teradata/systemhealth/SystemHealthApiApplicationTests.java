package com.teradata.systemhealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemHealthApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
